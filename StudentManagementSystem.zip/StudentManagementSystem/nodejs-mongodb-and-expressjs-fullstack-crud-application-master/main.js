const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");
const path = require("path");

app.use(cors());
app.use(express.json());
app.use(bodyParser.json());

const mongoURI = "mongodb://localhost:27017/sms";

mongoose
  .connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((err) => {
    console.log("Failed to connect to MongoDB:", err);
  });

const initialPath = path.join(__dirname, "public");
app.use(express.static(initialPath));

// app.get("/", (req, res) => {
//   res.sendFile(path.join(initialPath, "crude.html"));
// });

app.get("/",function(req,res){
  res.sendFile(__dirname + "/crude.html");
})

const schema = new mongoose.Schema({
  StudentId: Number,
  StudentName: String,
  ChemistryMarks: Number,
  PhysicsMarks: Number,
  MathsMarks: Number,
});

const model = mongoose.model("marks_details", schema);

app.post("/post", async (req, res) => {
  try {
    const data = new model(req.body);
    const savedData = await data.save();
    res.json(savedData);
  } catch (err) {
    res.status(500).json({ error: "An error occurred" });
  }
});

app.put("/update/:id", async (req, res) => {
  try {
    const updatedData = await model.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, useFindAndModify: false }
    );

    if (!updatedData) {
      return res.status(404).json({ error: "Nothing found" });
    }

    res.json(updatedData);
  } catch (err) {
    res.status(500).json({ error: "An error occurred" });
  }
});

app.get("/fulldata", async (req, res) => {
  try {
    const data = await model.find();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "An error occurred" });
  }
});

app.delete("/delete/:id", async (req, res) => {
  try {
    const deletedData = await model.findByIdAndDelete(req.params.id);

    if (!deletedData) {
      return res.status(404).json({ error: "Wrong id" });
    }

    res.json({ message: "Deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: "An error occurred" });
  }
});


const port = 3008;
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
